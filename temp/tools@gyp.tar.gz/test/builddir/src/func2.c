#include <stdio.h>

void func2(void)
{
  printf("Hello from func2.c\n");
}
