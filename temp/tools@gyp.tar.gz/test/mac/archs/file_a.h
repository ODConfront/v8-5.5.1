// Copyright (c) 2014 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef _INCLUDED_TEST_MAC_DEPENDENCIES_FILE_A_H_
#define _INCLUDED_TEST_MAC_DEPENDENCIES_FILE_A_H_

void DependentFunctionA();

#endif // _INCLUDED_TEST_MAC_DEPENDENCIES_FILE_A_H_
