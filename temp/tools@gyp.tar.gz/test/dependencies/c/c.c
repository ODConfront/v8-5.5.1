int funcC() {
  return 3
  // Intentional syntax error. This file should never be compiled, so this
  // shouldn't be a problem.
