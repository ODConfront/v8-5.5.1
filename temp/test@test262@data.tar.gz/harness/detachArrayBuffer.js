function $DETACHBUFFER(buffer) {
  throw new Test262Error("No method available to detach an ArrayBuffer");
}
